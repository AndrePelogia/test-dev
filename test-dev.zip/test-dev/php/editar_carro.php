<?php

include('conexao.php');

$id = $_POST['id'];

$valores = mysql_query("SELECT * FROM carros WHERE id = '$id'");
$valores2 = mysql_fetch_array($valores);

$dados = array(
    0 => $valores2['marca'],
    1 => $valores2['modelo'],
    2 => $valores2['ano'],
);
echo json_encode($dados);
?>