<?php

include('conexao.php');

$id = $_POST['id'];

mysql_query("DELETE FROM carros WHERE id = '$id'");

$registro = mysql_query("SELECT * FROM carros ORDER BY id ASC");

echo '<div class="table-responsive table-condensed ">
            <table class="table">
                <thead>
        	<tr>
            	<th class="active">Cód.</th>
                <th class="active">Marca</th>
                <th class="active">Modelo</th>
                <th class="active">Ano</th>
		<th class="active">Ações</th>
            </tr>
            </thead>
            <tbody>';
while ($registro2 = mysql_fetch_array($registro)) {
    echo '<tr>
				<td class="info">' . $registro2['id'] . '</td>
				<td class="info">' . $registro2['marca'] . '</td>
				<td class="info">' . $registro2['modelo'] . '</td>
				<td class="info">' . $registro2['ano'] . '</td>
				<td class="info"><a href="javascript:editarCarro(' . $registro2['id'] . ');" class="glyphicon glyphicon-edit" title="Editar"></a> <a href="javascript:deletarCarro(' . $registro2['id'] . ');" class="glyphicon glyphicon-remove-circle" title="Excluir"></a></td>
				</tr>
                           </tbody>';
}
echo '</table></div>';
?>