<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Carros</title>
        <link href="../css/style.css" rel="stylesheet">
        <script src="../js/jquery.js"></script>
        <script src="../js/myjava.js"></script>
        <link href="../bootstrap/css/bootstrap.css" rel="stylesheet">
        <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="../bootstrap/css/bootstrap-theme.css" rel="stylesheet">
        <link href="../bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
        <script src="../bootstrap/js/bootstrap.min.js"></script>
        <script src="../bootstrap/js/bootstrap.js"></script>
    </head>
    <body>
        <div class="container">
            <header>Registro de Carros</header>	

            <section>
                <table border="0" align="center">
                    <tr>
                        <td width="100"><button id="novo-carro" class="btn btn-success">Adicionar Carro</button></td>
                    </tr>
                </table>
            </section>

            <div class="registros" id="adicionar-carro">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th class="active">Cód.</th>
                                <th class="active">Marca</th>
                                <th class="active">Modelo</th>
                                <th class="active">Ano</th>
                                <th class="active">Ações</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php
                            include('../php/conexao.php');
                            $registro = mysql_query("SELECT * FROM carros");
                            while ($registro2 = mysql_fetch_array($registro)) {
                                echo '<tr>
                        <td class="info">' . $registro2['id'] . '</td>
                        <td class="info ">' . $registro2['marca'] . '</td>
                        <td class="info">' . $registro2['modelo'] . '</td>
                        <td class="info">' . $registro2['ano'] . '</td>
                        <td class="info"><a href="javascript:editarCarro(' . $registro2['id'] . ');" class="glyphicon glyphicon-edit" title="Editar"></a> <a href="javascript:deletarCarro(' . $registro2['id'] . ');" class="glyphicon glyphicon-remove-circle" title="Excluir"></a></td>
                    </tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- MODAL -->

        <div class="modal fade modalmy" id="cadastrar-carro" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel"><b>Cadastrar e Editar Carros</b></h4>
                </div>
                <form id="formulario" class="formulario" onsubmit="return adicionarCarro();">
                    <div class="modal-body">
                        <table border="0" width="auto">
                            <tr>
                                <td colspan="2"><input type="text" required="required" readonly="readonly" id="id" name="id" style="visibility:hidden; height:5px;"/></td>
                            </tr>
                            <tr>
                                <td >Ação: </td>
                                <td><input type="text" required="required" readonly="readonly" id="pro" name="pro"/></td>
                            </tr>
                            <tr>
                                <td>Marca: </td>
                                <td><select required="required" name="marca" id="marca">
                                        <option value="0">Selicione uma marca</option>
                                        <option value="GM">GM</option>
                                        <option value="VW">VW</option>
                                        <option value="Ford">Ford</option>
                                        <option value="Fiat">Fiat</option>
                                        <option value="Pegeot">Pegeot</option>
                                        <option value="Renault">Renault</option>
                                        <option value="Hyunday">Hyunday</option>
                                        <option value="Toyota">Toyota</option>
                                        <option value="Mitsubishi">Mitsubishi</option>
                                    </select></td>
                            </tr>
                            <tr>
                                <td>Modelo: </td>
                                <td><input type="text" required="required" name="modelo" id="modelo"/></td>
                            </tr>
                            <tr>
                                <td>Ano: </td>
                                <td><select required="required" name="ano" id="ano">
                                        <?php
                                        for ($i = 2016; $i >= 1950; $i--) {
                                            echo "<option>$i</option>";
                                        }
                                        ?>
                                    </select></td>
                            </tr>

                            <tr>
                                <td colspan="2">
                                    <div id="mensagem"></div>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <div class="modal-footer" style="text-align: center;">
                        <input type="submit" value="Cadastrar" class="btn btn-success" id="reg" />
                        <input type="submit" value="Alterar" class="btn btn-warning"  id="edi"/>
                    </div>
                </form>
            </div>
        </div>



    </body>
</html>
