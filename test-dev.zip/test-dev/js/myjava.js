$(function () {

    $('#novo-carro').on('click', function () {
        $('#formulario')[0].reset();
        $('#pro').val('Cadastro');
        $('#edi').hide();
        $('#reg').show();
        $('#cadastrar-carro').modal({
            show: true,
            backdrop: 'static'
        });
        return false;
    });

});

function adicionarCarro() {
    var url = '../php/adicionar_carro.php';
    $.ajax({
        type: 'POST',
        url: url,
        data: $('#formulario').serialize(),
        success: function (registro) {
            if ($('#pro').val() == 'Cadastro') {
                $('#formulario')[0].reset();
                $('#mensagem').addClass('bem').html('Cadastro realizado com sucesso!').show(200).delay(2500).hide(200);
                $('#adicionar-carro').html(registro);
                return false;
            } else {
                $('#mensagem').addClass('bem').html('Edição realizada com sucesso!').show(200).delay(2500).hide(200);
                $('#adicionar-carro').html(registro);
                return false;
            }
        }
    });
    return false;
}

function deletarCarro(id) {
    var url = '../php/deletar_carro.php';
    var pregunta = confirm('Tem certeza que deseja deletar este carro?');
    if (pregunta == true) {
        $.ajax({
            type: 'POST',
            url: url,
            data: 'id=' + id,
            success: function (registro) {
                $('#adicionar-carro').html(registro);
                return false;
            }
        });
        return false;
    } else {
        return false;
    }
}

function editarCarro(id) {
    $('#formulario')[0].reset();
    var url = '../php/editar_carro.php';
    $.ajax({
        type: 'POST',
        url: url,
        data: 'id=' + id,
        success: function (valores) {
            var dados = eval(valores);
            $('#reg').hide();
            $('#edi').show();
            $('#pro').val('Edicao');
            $('#id').val(id);
            $('#marca').val(dados[0]);
            $('#modelo').val(dados[1]);
            $('#ano').val(dados[2]);
            $('#cadastrar-carro').modal({
                show: true,
                backdrop: 'static'
            });
            return false;
        }
    });
    return false;
}