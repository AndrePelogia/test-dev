-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 01-Set-2016 às 20:21
-- Versão do servidor: 5.6.21
-- PHP Version: 5.5.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `carros`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `carros`
--

CREATE TABLE IF NOT EXISTS `carros` (
`id` int(11) NOT NULL,
  `marca` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `modelo` varchar(80) COLLATE utf8mb4_bin NOT NULL,
  `ano` int(4) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `carros`
--

INSERT INTO `carros` (`id`, `marca`, `modelo`, `ano`) VALUES
(17, 'Ford', 'Focus', 2010),
(18, 'Renault', 'Megane', 2007),
(19, 'Mitsubishi', 'L200', 2015),
(20, 'VW', 'Gol', 2010),
(21, 'Fiat', 'Bravo', 2005),
(22, 'Ford', 'KÃ¡', 1998),
(23, 'GM', 'Corsa', 2008),
(24, 'Hyunday', 'I35', 2013),
(25, 'VW', 'Tiguan', 2016),
(26, 'VW', 'Amarok', 2015),
(38, 'Hyunday', 'Hb20', 2015),
(40, 'Pegeot', '307', 2016);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carros`
--
ALTER TABLE `carros`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carros`
--
ALTER TABLE `carros`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=42;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
